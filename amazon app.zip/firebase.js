/*import firebase from "firebase";

// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
    apiKey: "AIzaSyCEzPacyms7IdQa8EvwtyVgTdZD0k6H17U",
    authDomain: "mestagram-9688b.firebaseapp.com",
    projectId: "mestagram-9688b",
    storageBucket: "mestagram-9688b.appspot.com",
    messagingSenderId: "804452693737",
    appId: "1:804452693737:web:489a1c46336206819a6278",
    measurementId: "G-9QVT6RE7C4"
  };

const firebaseApp = firebase.initializeApp(firebaseConfig)

const db = firebaseApp.firestore();
const auth = firebase.auth();

export {db, auth };*/
